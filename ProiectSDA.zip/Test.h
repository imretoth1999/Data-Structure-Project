#pragma once
class Test {
public:
	void testAdd();
	void testSearch();
	void testRemove();
	void testAll();
	void testIterator();
};